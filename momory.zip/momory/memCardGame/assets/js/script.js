
const TOTAL_PAIRS = 8;

const cards = document.querySelectorAll(".card");
const setupOverlay = document.getElementById("setup");
const setupForm = document.getElementById("setup-form");
const winnerOverlay = document.getElementById("winner");
const winnerTitle = document.getElementById("winner-title");
const winnerScores = document.getElementById("winner-scores");
const restartBtn = document.getElementById("restart");
const changeNamesBtn = document.getElementById("change-names");
const turnText = document.getElementById("turn-text");

const playerEls = [0, 1].map(i => ({
  box: document.getElementById(`player-${i}`),
  name: document.getElementById(`name-${i}`),
  score: document.getElementById(`score-${i}`),
}));

let players = [
  { name: "Jogador 1", score: 0 },
  { name: "Jogador 2", score: 0 },
];
let current = 0;
let matched = 0;
let cardOne = null;
let cardTwo = null;
let disableDeck = false;

/* ---------- Utilitários ---------- */

// Embaralhamento Fisher-Yates (mais justo que sort com Math.random)
function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function resetSelection() {
  cardOne = null;
  cardTwo = null;
  disableDeck = false;
}

function renderScoreboard() {
  players.forEach((p, i) => {
    playerEls[i].name.textContent = p.name;
    playerEls[i].score.textContent = p.score;
    playerEls[i].box.classList.toggle("active", i === current);
  });
  turnText.textContent = `Vez de ${players[current].name}`;
}

function bumpScore(i) {
  const el = playerEls[i].score;
  el.classList.remove("bump");
  void el.offsetWidth; // reinicia a animação
  el.classList.add("bump");
}

/* ---------- Lógica do jogo ---------- */

function flipCard(e) {
  const clicked = e.currentTarget;

  if (disableDeck || clicked === cardOne || clicked.classList.contains("matched")) return;

  clicked.classList.add("flip");

  if (!cardOne) {
    cardOne = clicked;
    return;
  }

  cardTwo = clicked;
  disableDeck = true;

  const img1 = cardOne.querySelector(".back-view img").src;
  const img2 = cardTwo.querySelector(".back-view img").src;
  checkMatch(img1, img2);
}

function checkMatch(img1, img2) {
  const a = cardOne;
  const b = cardTwo;

  if (img1 === img2) {
    [a, b].forEach(card => {
      card.classList.add("matched");
      card.removeEventListener("click", flipCard);
    });

    players[current].score++;
    bumpScore(current);
    matched++;
    renderScoreboard();
    resetSelection();

    if (matched === TOTAL_PAIRS) {
      setTimeout(showWinner, 700);
    }
    return;
  }

  // Erro: treme, desvira e passa a vez
  setTimeout(() => {
    a.classList.add("shake");
    b.classList.add("shake");
  }, 400);

  setTimeout(() => {
    a.classList.remove("shake", "flip");
    b.classList.remove("shake", "flip");
    current = 1 - current;
    resetSelection();
    renderScoreboard();
  }, 1200);
}

function showWinner() {
  const [p1, p2] = players;
  let title;

  if (p1.score === p2.score) {
    title = "Empate!";
  } else {
    const winner = p1.score > p2.score ? p1 : p2;
    title = `${winner.name} venceu!`;
  }

  winnerTitle.textContent = title;
  winnerScores.textContent = `${p1.name}: ${p1.score} pts  ·  ${p2.name}: ${p2.score} pts`;
  winnerOverlay.classList.remove("hidden");
}

function newGame() {
  matched = 0;
  current = 0;
  resetSelection();
  players.forEach(p => (p.score = 0));
  renderScoreboard();

  const images = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8]);

  cards.forEach((card, i) => {
    card.classList.remove("flip", "shake", "matched");
    card.querySelector(".back-view img").src = `assets/img/img-${images[i]}.png`;
    card.addEventListener("click", flipCard);
  });
}

/* ---------- Eventos de tela ---------- */

setupForm.addEventListener("submit", e => {
  e.preventDefault();

  const n1 = document.getElementById("p1").value.trim() || "Jogador 1";
  const n2 = document.getElementById("p2").value.trim() || "Jogador 2";

  players[0].name = n1;
  players[1].name = n2;

  setupOverlay.classList.add("hidden");
  newGame();
});

restartBtn.addEventListener("click", () => {
  winnerOverlay.classList.add("hidden");
  newGame();
});

changeNamesBtn.addEventListener("click", () => {
  winnerOverlay.classList.add("hidden");
  document.getElementById("p1").value = players[0].name;
  document.getElementById("p2").value = players[1].name;
  setupOverlay.classList.remove("hidden");
});

// Prepara o tabuleiro ao carregar
newGame();